Submission of Benvenuti Eloi Jean and Bronner Timothée

The code is in the src/ directory, the compiled class in the bin/ directory
Run the .jar with "java -jar benvenuti-bronner-in.jar" command.
